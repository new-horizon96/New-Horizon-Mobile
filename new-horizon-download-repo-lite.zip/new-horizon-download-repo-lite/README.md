# New Horizon - Download Repository

Repositório criado para hospedar a página/estrutura de download do aplicativo da New Horizon.

## Arquivo principal

O APK é grande demais para subir direto pelo upload comum do GitHub. O recomendado é colocar o arquivo em **GitHub Releases**.

Nome sugerido do arquivo:

```text
NewHorizon.apk
```

## Como publicar o APK no GitHub Releases

1. Crie o repositório no GitHub.
2. Envie estes arquivos para o repositório.
3. Vá em **Releases**.
4. Clique em **Create a new release**.
5. Use uma tag, por exemplo: `v1.0.0`.
6. Arraste o arquivo `NewHorizon.apk` para a área de anexos da release.
7. Publique a release.
8. Copie o link do APK publicado.

## Estrutura

```text
new-horizon-download-repo/
├─ README.md
├─ VERSION.txt
├─ .gitignore
└─ releases/
   └─ COLOQUE-O-APK-AQUI.txt
```

## Observação

O arquivo APK original tinha cerca de 280 MB, então pode falhar em downloads/exports grandes. Por isso este ZIP está leve e serve como estrutura inicial do repositório.
